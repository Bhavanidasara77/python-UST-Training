from django.shortcuts import render,redirect
from .models import Bike

def home(request):
    return render(request,'index.html')

def savedetails(request):
    datadict=request.POST
    filedict=request.FILES
    companyname=datadict['companyname']
    color=datadict['color']
    speed=datadict['speed']
    cost=datadict['cost']
    image=datadict['image']
    b=Bike()
    b.companyname=companyname
    b.color=color
    b.speed=speed
    b.cost=cost
    b.image=image
    b.save()
    return redirect('/')

def bikedetails(request):
    data=Bike.objects.all()
    return render(request,'details.html',{'data':data})

def updatedata(request,key):
    obj=Bike.objects.get(id=key)
    return render(request,'update.html',{'data':obj})

def updatingbike(request,key):
    data=request.GET['companyname']
    data_color=request.GET['color']
    data_speed=request.GET['speed']
    data_cost=request.GET['cost']
    data_image=request.GET['image']
    obj=Bike.objects.get(id=key)
    obj.companyname=data
    obj.color=data_color
    obj.speed=data_speed
    obj.cost=data_cost
    obj.image=data_image
    obj.save()
    return redirect('/showdetails')

def deletedata(request,key):
    obj=Bike.objects.get(id=key)
    obj=delete()
    return redirect('/showdeatils')


