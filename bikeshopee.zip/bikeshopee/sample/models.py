from django.db import models



class  Bike(models.Model):
    companyname=models.CharField(max_length=100)
    color=models.CharField(max_length=100)
    speed=models.IntegerField
    image=models.ImageField(upload_to='static/image')
    cost=models.IntegerField
