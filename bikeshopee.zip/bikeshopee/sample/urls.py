from django.urls import path
from .views import home,savedetails,bikedetails,updatedata,updatingbike,deletedata





urlpatterns = [
     path('',home),
     path('save',savedetails),
     path('showdetails',bikedetails),
     path('updatedata,/<int:key>',updatedata),
     path('updatedata/updating/<int:key>',updatingbike),
     path('deletedata/<int:key>',deletedata)


 ]