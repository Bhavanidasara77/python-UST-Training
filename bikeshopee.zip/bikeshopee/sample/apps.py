from django.apps import AppConfig


class SampleConfig(AppConfig):
    name = 'sample'
